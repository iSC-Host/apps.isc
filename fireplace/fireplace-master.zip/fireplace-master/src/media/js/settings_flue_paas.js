define('settings_local', [], function() {
    return {
        api_url: 'https://flue.paas.allizom.org',
        media_url: 'https://flue.paas.allizom.org/media'
    };
});
